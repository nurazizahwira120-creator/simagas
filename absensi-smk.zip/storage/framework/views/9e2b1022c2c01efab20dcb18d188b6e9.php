

<link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">


<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
<link rel="apple-touch-icon" sizes="192x192" href="<?php echo e(asset('images/logo/icon-192x192.png')); ?>">


<link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">


<meta name="theme-color" content="#0d9488">

<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="SIMAGAS">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">


<script>
    window.simagasTema = {
        KUNCI: 'simagas-tema',

        ambil: function () {
            try {
                return localStorage.getItem(this.KUNCI) === 'dark' ? 'dark' : 'light';
            } catch (e) {
                return 'light';
            }
        },

        pasang: function (tema) {
            document.documentElement.classList.toggle('dark', tema === 'dark');
            try {
                localStorage.setItem(this.KUNCI, tema);
            } catch (e) { /* tidak bisa disimpan; tetap berlaku untuk sesi ini. */ }
        },

        ganti: function () {
            this.pasang(this.ambil() === 'dark' ? 'light' : 'dark');
        },
    };

    window.simagasTema.pasang(window.simagasTema.ambil());

    /*
     | Pemuat Leaflet sesuai permintaan (peta di Pengaturan Sistem & Absen
     | Radius). Ditaruh di sini, bersama skrip tema, karena alasan yang sama:
     | ini skrip KLASIK di <head>, jadi ia sudah ada sebelum Livewire maupun
     | blok     <?php
        $__scriptKey = '2853228939-0';
        ob_start();
    ?> mana pun dijalankan. Kalau diletakkan di app.js (module,
     | selalu ditunda), pemanggilnya bisa berjalan lebih dulu dan mendapat
     | undefined.
     |
     | Leaflet dimuat HANYA di halaman yang benar-benar memakainya — bukan di
     | setiap halaman — dan hanya sekali walau dipanggil beberapa kali.
     |
     | Promise-nya DITOLAK, bukan digantung, kalau berkasnya gagal diunduh.
     | Internet sekolah bisa mati atau CDN diblokir, dan halaman Absen Radius
     | HARUS tetap bisa dipakai tanpa peta — jadi pemanggilnya perlu tahu
     | bahwa petanya gagal, bukan menunggu selamanya.
     */
    /*
     | Pendaftaran service worker.
     |
     | Dibungkus pengecekan isSecureContext, bukan langsung dipanggil: di
     | http:// biasa navigator.serviceWorker memang ADA tapi register()
     | selalu menolak, dan penolakan itu muncul sebagai error merah di
     | konsol setiap kali halaman dibuka. Error yang sudah pasti terjadi dan
     | tidak bisa diperbaiki pengguna hanya melatih orang mengabaikan konsol.
     |
     | Didaftarkan setelah 'load' supaya tidak berebut bandwidth dengan CSS
     | dan JS halaman yang sedang dibuka.
     */
    if ('serviceWorker' in navigator && window.isSecureContext) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('<?php echo e(asset('sw.js')); ?>', { scope: '/' })
                .catch(function () { /* diabaikan: aplikasi tetap jalan tanpa PWA. */ });
        });
    }

    window.muatLeaflet = (function () {
        var janji = null;

        return function () {
            if (window.L) return Promise.resolve(window.L);
            if (janji) return janji;

            janji = new Promise(function (selesai, gagal) {
                var gaya = document.createElement('link');
                gaya.rel = 'stylesheet';
                gaya.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
                document.head.appendChild(gaya);

                var skrip = document.createElement('script');
                skrip.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
                skrip.onload = function () { selesai(window.L); };
                skrip.onerror = function () {
                    janji = null;
                    gagal(new Error('Leaflet gagal dimuat'));
                };
                document.head.appendChild(skrip);
            });

            return janji;
        };
    })();
</script>

<?php echo $__env->make('partials.sweetalert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php
    $adaVite = file_exists(public_path('hot'))
        || file_exists(public_path('build/manifest.json'));

    // Penanda versi supaya browser tidak menyajikan CSS lama dari cache
    // setelah update. filemtime dibungkus @ karena berkasnya boleh saja tidak ada.
    $capCss = @filemtime(public_path('simagas.css')) ?: 1;
    $capJs = @filemtime(public_path('simagas.js')) ?: 1;
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($adaVite): ?>
    
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<?php else: ?>
    <link rel="stylesheet" href="<?php echo e(asset('simagas.css')); ?>?v=<?php echo e($capCss); ?>">
    <script src="<?php echo e(asset('simagas.js')); ?>?v=<?php echo e($capJs); ?>" defer></script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\laragon\www\absensi-smk\resources\views/partials/head-assets.blade.php ENDPATH**/ ?>