<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0d9488">
    
    <title><?php if (! empty(trim($__env->yieldContent('title')))): ?><?php echo $__env->yieldContent('title'); ?> — SIMAGAS@else<?php echo e('SIMAGAS - Sistem Absensi Digital'); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></title>

    
    <?php echo $__env->make('partials.head-assets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="min-h-screen bg-gray-50 font-sans text-gray-700 antialiased dark:bg-gray-900 dark:text-gray-300">


<div id="splash-screen"
    x-data="{ show: true }"
    x-show="show"
    x-init="
        const tutup = () => setTimeout(() => show = false, 1000);
        if (document.readyState === 'complete') { tutup(); }
        else { window.addEventListener('load', tutup, { once: true }); }
        setTimeout(() => show = false, 4000);
    "
    x-transition:leave="transition ease-in duration-700"
    x-transition:leave-start="opacity-100 transform scale-100"
    x-transition:leave-end="opacity-0 transform scale-110"
    role="status"
    aria-live="polite"
    class="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900">

    <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo SIMAGAS"
        class="mb-8 h-auto w-56 animate-pulse drop-shadow-xl md:w-64">

    
    <div class="flex items-center gap-2.5">
        <span class="h-3.5 w-3.5 animate-bounce rounded-full bg-brand-400 [animation-delay:-0.32s]"></span>
        <span class="h-3.5 w-3.5 animate-bounce rounded-full bg-brand-500 [animation-delay:-0.16s]"></span>
        <span class="h-3.5 w-3.5 animate-bounce rounded-full bg-gray-800 dark:bg-gray-200"></span>
    </div>

    <p class="mt-6 text-sm font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400">Memuat Sistem...</p>
</div>

<script>
    // Lapis pengaman ke-3 (lihat catatan di atas): murni JavaScript biasa,
    // tanpa Alpine. Kalau setelah 8 detik splash masih terlihat, berarti
    // Alpine memang tidak pernah jalan — buang paksa elemennya supaya
    // aplikasinya tetap bisa dipakai.
    setTimeout(function () {
        var splash = document.getElementById('splash-screen');
        if (splash && splash.style.display !== 'none') {
            splash.remove();
        }
    }, 8000);
</script>

<?php
    /*
     | VERSI_ASET — harus sama persis dengan --simagas-versi di
     | resources/css/app.css. Dibandingkan di JavaScript bawah halaman.
     |
     | Kenapa ada: kegagalan paling sering saat update paket ini adalah
     | `resources/views` tersalin tapi CSS hasil build-nya TIDAK. Tailwind
     | cuma mengompilasi class yang ia temukan di source, jadi class yang
     | baru muncul di paket ini tidak ada sama sekali di CSS lama —
     | sidebar hilang, kolom pencarian hilang, nama pengguna hilang, dan
     | browser tidak melaporkan apa pun karena bagi Tailwind class tak
     | dikenal bukan error. Pernah terjadi dan butuh berjam-jam untuk
     | ditelusuri; sekarang aplikasinya yang memberi tahu sendiri.
     */
    $versiAset = '2026-09-03a';

    $pengguna = auth()->user();
    $inisial = $pengguna
        ? Str::of($pengguna->name)->explode(' ')->map(fn ($p) => mb_substr($p, 0, 1))->take(2)->implode('')
        : '?';
    $adaPencarian = $panelPrefix !== '' && Route::has($panelPrefix . '.siswa.index');
    $adaProfil = $panelPrefix !== '' && Route::has($panelPrefix . '.profil');
?>


<div id="sidebar-overlay"
    class="fixed inset-0 z-40 hidden bg-gray-900/50 backdrop-blur-[2px] lg:hidden print:hidden"
    aria-hidden="true"></div>



<div class="flex h-screen overflow-hidden print:block print:h-auto print:overflow-visible">

    
    <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>

    <div id="area-konten"
        class="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden print:overflow-visible">

        
        <header class="sticky top-0 z-30 flex w-full border-b border-gray-200 bg-white/95 backdrop-blur dark:border-gray-800 dark:bg-gray-900/95 print:hidden">
            <div class="flex w-full items-center gap-2 px-4 py-3 sm:gap-4 md:px-6 lg:py-4">

                
                <button type="button" id="sidebar-open"
                    class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-gray-200 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 motion-reduce:transition-none lg:h-11 lg:w-11 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200"
                    aria-label="Buka menu" aria-controls="sidebar" aria-expanded="false">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'menu','class' => 'h-5 w-5 lg:hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','class' => 'h-5 w-5 lg:hidden']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-double-left','class' => 'hidden h-5 w-5 lg:block']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-double-left','class' => 'hidden h-5 w-5 lg:block']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </button>

                <div class="min-w-0 flex-1">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($adaPencarian): ?>
                        
                        <form method="GET" action="<?php echo e(route($panelPrefix . '.siswa.index')); ?>" class="hidden max-w-md sm:block">
                            <label for="topbar-search" class="sr-only">Cari siswa</label>
                            <div class="relative">
                                <span class="pointer-events-none absolute inset-y-0 left-4 flex items-center text-gray-400">
                                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'h-5 w-5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                </span>
                                <input id="topbar-search" type="search" name="cari" value="<?php echo e(request('cari')); ?>"
                                    placeholder="Cari siswa…"
                                    class="shadow-theme-xs h-11 w-full rounded-lg border border-gray-200 bg-transparent py-2.5 pl-11 pr-4 text-sm text-gray-800 placeholder:text-gray-400 focus:border-brand-300 focus:outline-none focus:ring-3 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200 dark:placeholder:text-gray-500">
                            </div>
                        </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="flex shrink-0 items-center gap-2 sm:gap-3">

                    
                    <button type="button" id="installPwaBtn" hidden
                        class="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-100 px-4 py-2 transition duration-300 hover:bg-gray-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 dark:border-gray-800 dark:bg-gray-800 dark:hover:bg-gray-700"
                        title="Pasang SIMAGAS sebagai aplikasi di perangkat ini">
                        <img src="<?php echo e(asset('images/logo/icon-192x192.png')); ?>" alt=""
                            class="h-6 w-6 rounded-md">
                        <span class="hidden text-sm font-medium text-gray-800 sm:block dark:text-white">Install App</span>
                    </button>


                    
                    <button type="button" id="tombol-tema"
                        class="flex h-10 w-10 items-center justify-center rounded-full border border-gray-200 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 motion-reduce:transition-none lg:h-11 lg:w-11 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-gray-200"
                        aria-label="Ganti mode terang / gelap">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'moon','class' => 'h-5 w-5 dark:hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'moon','class' => 'h-5 w-5 dark:hidden']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'sun','class' => 'hidden h-5 w-5 dark:block']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sun','class' => 'hidden h-5 w-5 dark:block']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    </button>

                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layouts.notification-bell', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2798478387-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengguna): ?>
                        <div class="relative" data-dropdown>
                            <button type="button" data-dropdown-tombol
                                class="flex items-center gap-2 rounded-full text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                                aria-haspopup="true" aria-expanded="false">
                                
                                <span class="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-brand-500 text-xs font-bold text-white lg:h-11 lg:w-11">
                                    <?php echo e($inisial); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengguna->foto_url): ?>
                                        <img src="<?php echo e($pengguna->foto_url); ?>" alt="" onerror="this.remove()"
                                            class="absolute inset-0 h-full w-full object-cover">
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </span>
                                <span class="hidden min-w-0 md:block">
                                    <span class="block max-w-[9rem] truncate text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e($pengguna->name); ?></span>
                                    <span class="block text-xs text-gray-400 dark:text-gray-500"><?php echo e($pengguna->role->label()); ?></span>
                                </span>
                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','class' => 'hidden h-4 w-4 text-gray-400 md:block']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => 'hidden h-4 w-4 text-gray-400 md:block']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            </button>

                            <div data-dropdown-panel hidden
                                class="shadow-theme-lg absolute right-0 mt-2 w-60 rounded-2xl border border-gray-200 bg-white p-3 dark:border-gray-800 dark:bg-gray-900">
                                <div class="border-b border-gray-200 px-2 pb-3 dark:border-gray-800">
                                    <p class="truncate text-sm font-semibold text-gray-800 dark:text-gray-200"><?php echo e($pengguna->name); ?></p>
                                    <p class="truncate text-xs text-gray-500 dark:text-gray-400"><?php echo e($pengguna->email); ?></p>
                                </div>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($adaProfil): ?>
                                    <a href="<?php echo e(route($panelPrefix . '.profil')); ?>"
                                        class="mt-2 flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/5">
                                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'identification','class' => 'h-5 w-5 text-gray-500 dark:text-gray-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'identification','class' => 'h-5 w-5 text-gray-500 dark:text-gray-400']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                        Profil Saya
                                    </a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-1">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-error-50 hover:text-error-600 dark:text-gray-300 dark:hover:bg-error-500/10 dark:hover:text-error-500">
                                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'logout','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','class' => 'h-5 w-5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                        Keluar
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </header>

        
        <main class="mx-auto w-full max-w-[1536px] p-4 md:p-6">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-success-200 bg-success-50 p-4 dark:border-success-500/30 dark:bg-success-500/10">
                    <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-success-500/15 text-success-600 dark:text-success-500">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','class' => 'h-5 w-5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    </span>
                    <p class="pt-1.5 text-sm font-medium text-success-700 dark:text-success-500"><?php echo e(session('status')); ?></p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                <div class="mb-6 flex items-start gap-3 rounded-2xl border border-error-200 bg-error-50 p-4 dark:border-error-500/30 dark:bg-error-500/10">
                    <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-error-500/15 text-error-600 dark:text-error-500">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'exclamation-triangle','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'exclamation-triangle','class' => 'h-5 w-5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    </span>
                    <ul class="space-y-1 pt-1.5 text-sm font-medium text-error-700 dark:text-error-500">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <li><?php echo e($error); ?></li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>

        </main>
    </div>
</div>

<script>
    /*
     | Perilaku kerangka: sidebar, mode ciut, dropdown, dan tombol tema.
     |
     | Ditulis JavaScript biasa, BUKAN Alpine — walau TailAdmin aslinya
     | memakai Alpine untuk semua ini. Alasannya satu: Alpine di project ini
     | datang menumpang di dalam bundel Livewire. Kalau Livewire gagal dimuat
     | (belum di-composer require, atau berkasnya kena cache rusak), seluruh
     | navigasi ikut mati — menu tidak bisa dibuka, tombol logout di dropdown
     | tidak terjangkau. Dengan JS biasa, kerangkanya tetap hidup apa pun yang
     | terjadi pada Livewire.
     */
    (function () {
        // ---- Sidebar (layar kecil) & mode ciut (layar besar) -------------
        var sidebar = document.getElementById('sidebar');
        var overlay = document.getElementById('sidebar-overlay');
        var tombolBuka = document.getElementById('sidebar-open');
        var tombolTutup = document.getElementById('sidebar-close');
        var LEBAR_DESKTOP = window.matchMedia('(min-width: 1024px)');
        var KUNCI_CIUT = 'simagas-sidebar-ciut';

        function bacaCiut() {
            try { return localStorage.getItem(KUNCI_CIUT) === '1'; } catch (e) { return false; }
        }

        function pasangCiut(ciut) {
            document.body.classList.toggle('sidebar-ciut', ciut);
            try { localStorage.setItem(KUNCI_CIUT, ciut ? '1' : '0'); } catch (e) { /* diabaikan */ }
        }

        // Diterapkan lebih awal supaya sidebar tidak sempat terlihat lebar
        // dulu lalu menyempit sendiri di depan mata pengguna.
        if (bacaCiut()) document.body.classList.add('sidebar-ciut');

        function buka() {
            if (!sidebar) return;
            sidebar.classList.remove('-translate-x-full');
            if (overlay) overlay.classList.remove('hidden');
            tombolBuka.setAttribute('aria-expanded', 'true');
            document.body.classList.add('overflow-hidden');
        }

        function tutup() {
            if (!sidebar) return;
            sidebar.classList.add('-translate-x-full');
            if (overlay) overlay.classList.add('hidden');
            tombolBuka.setAttribute('aria-expanded', 'false');
            document.body.classList.remove('overflow-hidden');
        }

        if (tombolBuka) {
            tombolBuka.addEventListener('click', function () {
                if (LEBAR_DESKTOP.matches) {
                    pasangCiut(!document.body.classList.contains('sidebar-ciut'));
                } else {
                    var terbuka = tombolBuka.getAttribute('aria-expanded') === 'true';
                    terbuka ? tutup() : buka();
                }
            });
        }

        if (tombolTutup) tombolTutup.addEventListener('click', tutup);
        if (overlay) overlay.addEventListener('click', tutup);

        // Kalau layar dibesarkan ke ukuran desktop saat menu mobile terbuka,
        // kunci scroll body harus ikut dilepas.
        LEBAR_DESKTOP.addEventListener('change', function (e) {
            if (e.matches) tutup();
        });

        // ---- Tombol pasang aplikasi (PWA) --------------------------------
        /*
         | Browser memutuskan sendiri KAPAN sebuah situs layak dipasang. Kalau
         | syaratnya terpenuhi (manifest valid + service worker + HTTPS/
         | localhost) ia menembakkan 'beforeinstallprompt'; kalau tidak,
         | event itu tidak pernah datang dan tombolnya tetap tersembunyi.
         | Itu perilaku yang benar: tombol yang mati saat diklik jauh lebih
         | membingungkan daripada tombol yang memang tidak ada.
         |
         | Di iPhone event ini tidak ada sama sekali — Safari iOS memasang
         | lewat menu Bagikan > Tambahkan ke Layar Utama. Jadi tombol ini
         | memang tidak akan muncul di sana, dan itu disengaja.
         */
        var tombolPasang = document.getElementById('installPwaBtn');
        var promptTertunda = null;

        // Sudah berjalan sebagai aplikasi terpasang? Jangan tawarkan lagi.
        var sudahTerpasang = window.matchMedia('(display-mode: standalone)').matches
            || window.navigator.standalone === true;

        if (tombolPasang && !sudahTerpasang) {
            window.addEventListener('beforeinstallprompt', function (e) {
                // Menahan tawaran bawaan browser supaya pemasangan terjadi
                // saat pengguna menekan tombol kita, bukan sebagai spanduk
                // yang muncul mendadak di tengah halaman.
                e.preventDefault();
                promptTertunda = e;
                tombolPasang.hidden = false;
            });

            tombolPasang.addEventListener('click', function () {
                if (!promptTertunda) return;

                tombolPasang.hidden = true;
                promptTertunda.prompt();

                promptTertunda.userChoice.then(function (pilihan) {
                    // Kalau pengguna membatalkan, tombolnya DIMUNCULKAN LAGI.
                    // Brief menyembunyikannya secara permanen; itu berarti
                    // orang yang tidak sengaja menekan "Nanti" kehilangan
                    // satu-satunya jalan memasang aplikasi sampai ia
                    // menemukan menu tersembunyi di browsernya.
                    if (pilihan && pilihan.outcome !== 'accepted') {
                        tombolPasang.hidden = false;
                    }

                    // Event ini hanya boleh dipakai sekali; browser akan
                    // mengirim yang baru kalau memang masih menawarkan.
                    promptTertunda = null;
                });
            });

            window.addEventListener('appinstalled', function () {
                tombolPasang.hidden = true;
                promptTertunda = null;
            });
        }

        // ---- Tombol ganti tema -------------------------------------------
        var tombolTema = document.getElementById('tombol-tema');
        if (tombolTema && window.simagasTema) {
            tombolTema.addEventListener('click', function () {
                window.simagasTema.ganti();
            });
        }

        // ---- Dropdown (notifikasi & pengguna) ----------------------------
        // Satu handler untuk semua dropdown: setiap wadah cukup diberi
        // data-dropdown, tombolnya data-dropdown-tombol, panelnya
        // data-dropdown-panel. Menambah dropdown baru nanti tidak perlu
        // menulis JavaScript lagi.
        var dropdowns = Array.prototype.slice.call(document.querySelectorAll('[data-dropdown]'));

        function tutupSemuaDropdown(kecuali) {
            dropdowns.forEach(function (d) {
                if (d === kecuali) return;
                var panel = d.querySelector('[data-dropdown-panel]');
                var tombol = d.querySelector('[data-dropdown-tombol]');
                if (panel) panel.hidden = true;
                if (tombol) tombol.setAttribute('aria-expanded', 'false');
            });
        }

        dropdowns.forEach(function (d) {
            var tombol = d.querySelector('[data-dropdown-tombol]');
            var panel = d.querySelector('[data-dropdown-panel]');
            if (!tombol || !panel) return;

            tombol.addEventListener('click', function (e) {
                e.stopPropagation();
                var akanBuka = panel.hidden;
                tutupSemuaDropdown(d);

                // Lonceng notifikasi memakai Alpine (komponen Livewire
                // tersendiri), jadi ia tidak ikut tersapu tutupSemuaDropdown.
                // Dua sistem dropdown itu saling memberi tahu lewat event ini
                // supaya tidak pernah ada dua panel terbuka bersamaan.
                if (akanBuka) window.dispatchEvent(new CustomEvent('simagas-tutup-dropdown'));

                panel.hidden = !akanBuka;
                tombol.setAttribute('aria-expanded', akanBuka ? 'true' : 'false');
            });

            panel.addEventListener('click', function (e) { e.stopPropagation(); });
        });

        document.addEventListener('click', function () { tutupSemuaDropdown(null); });

        // Arah sebaliknya: lonceng dibuka -> dropdown lain ditutup.
        window.addEventListener('simagas-tutup-lain', function () { tutupSemuaDropdown(null); });

        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') return;
            tutupSemuaDropdown(null);
            tutup();
        });

        // ---- Pemeriksa versi CSS -----------------------------------------
        // Lihat catatan pada $versiAset di atas. Kalau CSS-nya tertinggal,
        // halaman akan terlihat rusak tanpa satu pun pesan error — jadi
        // pesannya dibuat di sini.
        var versiBlade = <?php echo json_encode($versiAset, 15, 512) ?>;
        var versiCss = getComputedStyle(document.documentElement)
            .getPropertyValue('--simagas-versi').trim().replace(/^["']|["']$/g, '');

        if (versiCss !== versiBlade) {
            var pita = document.createElement('div');
            pita.setAttribute('role', 'alert');
            pita.style.cssText =
                'position:fixed;left:0;right:0;bottom:0;z-index:99999;' +
                'background:#7a271a;color:#fff;padding:14px 18px;' +
                'font:14px/1.5 system-ui,sans-serif;text-align:left';
            pita.innerHTML =
                '<strong>Tampilan tidak akan benar: berkas CSS-nya versi lama.</strong><br>' +
                'CSS terbaca <code>' + (versiCss || 'tidak ada') + '</code>, seharusnya <code>' +
                versiBlade + '</code>. Salin ulang folder <code>public/build/</code> ' +
                'beserta <code>public/simagas.css</code> dari paket, lalu tekan Ctrl+Shift+R. ' +
                'Kalau Anda memakai npm, jalankan <code>npm run build</code>.';
            document.body.appendChild(pita);
        }
    })();
</script>


<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>



<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\absensi-smk\resources\views/layouts/app.blade.php ENDPATH**/ ?>