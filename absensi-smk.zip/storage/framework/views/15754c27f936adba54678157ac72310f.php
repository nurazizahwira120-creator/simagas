<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0f766e">
    <title><?php echo e($title ?? 'Masuk'); ?> — SIMAGAS</title>

    
    <meta name="robots" content="noindex, nofollow">

    <?php echo $__env->make('partials.head-assets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="min-h-screen bg-brand-surface-muted font-sans text-brand-ink antialiased">

    

    <?php echo e($slot); ?>


    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\absensi-smk\resources\views/layouts/tamu.blade.php ENDPATH**/ ?>