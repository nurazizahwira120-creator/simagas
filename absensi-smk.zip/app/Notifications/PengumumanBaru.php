<?php

namespace App\Notifications;

use App\Models\Pengumuman;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Str;

/**
 * Pengumuman broadcast yang masuk ke lonceng setiap penerima.
 *
 * Saluran 'database' saja. Pengiriman WhatsApp untuk pengumuman ditangani
 * TERPISAH di App\Livewire\KirimPengumuman lewat job SendWhatsAppNotification,
 * bukan lewat channel notifikasi — supaya jeda antar pesan bisa diatur
 * (syarat gateway Fonnte agar nomor tidak diblokir) dan supaya pengumuman
 * tetap masuk ke lonceng walau pengirimannya lewat WhatsApp gagal.
 */
class PengumumanBaru extends Notification
{
    public function __construct(
        private readonly int $pengumumanId,
        private readonly string $judul,
        private readonly string $isi,
        private readonly string $pengirim,
    ) {}

    public static function dari(Pengumuman $pengumuman): self
    {
        return new self(
            $pengumuman->id,
            $pengumuman->judul,
            $pengumuman->isi_pesan,
            $pengumuman->pembuat?->name ?? 'Sekolah',
        );
    }

    /** @return array<int, string> */
    public function via(object $notifiable): array
    {
        return ['database'];
    }

    /** @return array<string, mixed> */
    public function toArray(object $notifiable): array
    {
        return [
            'judul' => $this->judul,
            'pesan' => 'Pengumuman dari ' . $this->pengirim,
            'cuplikan' => Str::limit($this->isi, 120),
            'ikon' => 'bell',
            'warna' => 'info',
            'pengumuman_id' => $this->pengumumanId,

            // Pengumuman TIDAK punya halaman tujuan sendiri: isinya sudah
            // tampil utuh di dalam lonceng. Membuat halaman detail hanya untuk
            // menampilkan dua paragraf yang sama berarti satu klik tambahan
            // tanpa informasi tambahan.
            'rute' => null,
        ];
    }
}
